#! /bin/sh

./Bat_cbind_confidence_interval.sh
./Bat_awk_custom2.sh
./Bat_slidingwindow.sh
